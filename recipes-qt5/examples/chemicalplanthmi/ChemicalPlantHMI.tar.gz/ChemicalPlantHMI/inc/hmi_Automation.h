#ifndef HMI_AUTOMATION_H
#define HMI_AUTOMATION_H

#include <QWidget>
#include "common.h"
#include "hmiDisplayScreen.h"

/*!
 * \brief The HMI_Automation class
 */
class HMI_Automation : public QWidget
{
    Q_OBJECT

public:
    /*!
     * \brief HMI_Automation
     * \param parent
     */
    HMI_Automation(QWidget *parent = 0);

    ~HMI_Automation();

    /*!
     * \brief m_HMIDisplay
     */
    HMIDisplay *m_HMIDisplay;

};

#endif // HMI_AUTOMATION_H
