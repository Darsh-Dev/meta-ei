#ifndef HMIDISPLAY_H
#define HMIDISPLAY_H

#include <QWidget>
#include <QQmlContext>
#include <QtQuick/QQuickItem>
#include <QtQuick/QQuickView>

#include "common.h"
class HMIDisplay : public QWidget
{
    Q_OBJECT
public:
    explicit HMIDisplay(QWidget *parent = nullptr);
    QQuickView *view;


signals:

public slots:
    void receiveFromQml();

private:
};

#endif // HMIDISPLAY_H
