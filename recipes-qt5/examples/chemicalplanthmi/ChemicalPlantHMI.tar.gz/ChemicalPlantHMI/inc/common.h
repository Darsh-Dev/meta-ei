#ifndef COMMON_H
#define COMMON_H

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QDebug>
#include <QApplication>
#include <QDesktopWidget>
#include <QLineEdit>
#include <QTimer>
#include <QThread>
#include <QtQuick/QQuickView>
#include <QtQuickWidgets/QQuickWidget>
#include <QFrame>
#include <QMainWindow>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QtCharts/QChart>
#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>
#include <QtCharts/QSplineSeries>
#include <QtCharts/QValueAxis>
#include <QtCharts/QCategoryAxis>
#include <QtCharts/QDateTimeAxis>
#include <QTextStream>
#include <QDateTime>
#include <QtCharts/QDateTimeAxis>
#include <QtCore/QFile>
#include <QtCore/QTextStream>
#include <QPainter>
#include <QWidget>
#include <QToolButton>



#endif // COMMON_H
