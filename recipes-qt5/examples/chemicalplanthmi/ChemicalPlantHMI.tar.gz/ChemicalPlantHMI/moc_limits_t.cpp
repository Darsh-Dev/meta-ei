/****************************************************************************
** Meta object code from reading C++ file 'limits_t.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "inc/limits_t.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'limits_t.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_LIMITS_T_t {
    QByteArrayData data[14];
    char stringdata0[176];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_LIMITS_T_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_LIMITS_T_t qt_meta_stringdata_LIMITS_T = {
    {
QT_MOC_LITERAL(0, 0, 8), // "LIMITS_T"
QT_MOC_LITERAL(1, 9, 10), // "minChanged"
QT_MOC_LITERAL(2, 20, 0), // ""
QT_MOC_LITERAL(3, 21, 15), // "minlevelChanged"
QT_MOC_LITERAL(4, 37, 26), // "minlevelTemperatureChanged"
QT_MOC_LITERAL(5, 64, 7), // "readMin"
QT_MOC_LITERAL(6, 72, 8), // "writeMin"
QT_MOC_LITERAL(7, 81, 3), // "min"
QT_MOC_LITERAL(8, 85, 8), // "levelMin"
QT_MOC_LITERAL(9, 94, 13), // "writelevelMin"
QT_MOC_LITERAL(10, 108, 5), // "level"
QT_MOC_LITERAL(11, 114, 19), // "levelMinTemperature"
QT_MOC_LITERAL(12, 134, 24), // "writelevelMinTemperature"
QT_MOC_LITERAL(13, 159, 16) // "temperatureLevel"

    },
    "LIMITS_T\0minChanged\0\0minlevelChanged\0"
    "minlevelTemperatureChanged\0readMin\0"
    "writeMin\0min\0levelMin\0writelevelMin\0"
    "level\0levelMinTemperature\0"
    "writelevelMinTemperature\0temperatureLevel"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_LIMITS_T[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       3,   74, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   59,    2, 0x06 /* Public */,
       3,    0,   60,    2, 0x06 /* Public */,
       4,    0,   61,    2, 0x06 /* Public */,

 // methods: name, argc, parameters, tag, flags
       5,    0,   62,    2, 0x02 /* Public */,
       6,    1,   63,    2, 0x02 /* Public */,
       8,    0,   66,    2, 0x02 /* Public */,
       9,    1,   67,    2, 0x02 /* Public */,
      11,    0,   70,    2, 0x02 /* Public */,
      12,    1,   71,    2, 0x02 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // methods: parameters
    QMetaType::Float,
    QMetaType::Void, QMetaType::Float,    7,
    QMetaType::Float,
    QMetaType::Void, QMetaType::Float,   10,
    QMetaType::Int,
    QMetaType::Void, QMetaType::Int,   13,

 // properties: name, type, flags
       7, QMetaType::Float, 0x00495003,
      10, QMetaType::Float, 0x00495003,
      13, QMetaType::Int, 0x00495003,

 // properties: notify_signal_id
       0,
       1,
       2,

       0        // eod
};

void LIMITS_T::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        LIMITS_T *_t = static_cast<LIMITS_T *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->minChanged(); break;
        case 1: _t->minlevelChanged(); break;
        case 2: _t->minlevelTemperatureChanged(); break;
        case 3: { float _r = _t->readMin();
            if (_a[0]) *reinterpret_cast< float*>(_a[0]) = std::move(_r); }  break;
        case 4: _t->writeMin((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 5: { float _r = _t->levelMin();
            if (_a[0]) *reinterpret_cast< float*>(_a[0]) = std::move(_r); }  break;
        case 6: _t->writelevelMin((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 7: { int _r = _t->levelMinTemperature();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 8: _t->writelevelMinTemperature((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (LIMITS_T::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&LIMITS_T::minChanged)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (LIMITS_T::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&LIMITS_T::minlevelChanged)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (LIMITS_T::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&LIMITS_T::minlevelTemperatureChanged)) {
                *result = 2;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        LIMITS_T *_t = static_cast<LIMITS_T *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< float*>(_v) = _t->readMin(); break;
        case 1: *reinterpret_cast< float*>(_v) = _t->levelMin(); break;
        case 2: *reinterpret_cast< int*>(_v) = _t->levelMinTemperature(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        LIMITS_T *_t = static_cast<LIMITS_T *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->writeMin(*reinterpret_cast< float*>(_v)); break;
        case 1: _t->writelevelMin(*reinterpret_cast< float*>(_v)); break;
        case 2: _t->writelevelMinTemperature(*reinterpret_cast< int*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject LIMITS_T::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_LIMITS_T.data,
      qt_meta_data_LIMITS_T,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *LIMITS_T::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *LIMITS_T::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_LIMITS_T.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int LIMITS_T::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 9;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 3;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void LIMITS_T::minChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void LIMITS_T::minlevelChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void LIMITS_T::minlevelTemperatureChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
