#include "hmi_Automation.h"
#include <QApplication>
/*!
 * \brief main
 * \param argc
 * \param argv
 * \return
 */
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    HMI_Automation w;
     w.show();
     w.setStyleSheet("background-color: #dcdee2");
     w.setFixedSize(1150,640);

    return a.exec();
}
