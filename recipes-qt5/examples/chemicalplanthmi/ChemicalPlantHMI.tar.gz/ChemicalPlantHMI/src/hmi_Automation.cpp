#include "hmi_Automation.h"

/*!
 * \brief HMI_Automation::HMI_Automation
 * \param parent
 * The class HMI_Automation is used as main widget class.
 */
HMI_Automation::HMI_Automation(QWidget *parent)
    : QWidget(parent)
{
    QHBoxLayout *main_Layout =new QHBoxLayout;

   QVBoxLayout *l_Layout =new QVBoxLayout;

   QHBoxLayout *l_HVLayout =new QHBoxLayout;

   QHBoxLayout *l_HLayout =new QHBoxLayout;

   m_HMIDisplay =new HMIDisplay();

   l_HLayout->addWidget(m_HMIDisplay);
   l_HLayout->addStretch(0);
   l_HVLayout->addStretch(0);

   l_Layout->addLayout(l_HLayout);


   main_Layout->addLayout(l_Layout);
   this->setLayout(main_Layout);
}

HMI_Automation::~HMI_Automation()
{

}
