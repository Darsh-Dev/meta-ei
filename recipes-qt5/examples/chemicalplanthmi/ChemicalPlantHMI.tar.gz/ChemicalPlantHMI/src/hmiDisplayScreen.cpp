#include "hmiDisplayScreen.h"

/*!
 * \brief HMIDisplay::HMIDisplay
 * \param parent
 * The HMIDisplay class is used as display QML display screen.
 */
HMIDisplay::HMIDisplay(QWidget *parent) : QWidget(parent)
{

    QHBoxLayout *l_Layout =new QHBoxLayout();
    /*!
     * \brief l_HMIDisplayFrame
     * The l_HMIDisplayFrame is used for display main.qml in QFrame.
     */

    QFrame *l_HMIDisplayFrame =new QFrame();
    l_HMIDisplayFrame->setFrameShape(QFrame::StyledPanel);
    l_HMIDisplayFrame->setFrameShadow(QFrame::Raised);
    l_HMIDisplayFrame->setFrameStyle(QFrame::Raised |QFrame::Panel);
    l_HMIDisplayFrame->setFixedSize(1125,610);

    l_HMIDisplayFrame->setStyleSheet("background-color: #c7ccd6");

    /*!
     * \brief l_HorizontalView
     *
     */
    QHBoxLayout  *l_HorizontalView =new QHBoxLayout(l_HMIDisplayFrame);

    /*!
     * \brief view
     * The view is used for display display qml file in QWidget.
     */
    view = new QQuickView();

    QWidget *container = QWidget::createWindowContainer(view, this);
    container->setFixedSize(1100,590);
    container->setFocusPolicy(Qt::TabFocus);
    view->setSource(QUrl("qrc:/component/main.qml"));


    l_HorizontalView->addWidget(container);
    l_Layout->addWidget(l_HMIDisplayFrame);
    this->setLayout(l_Layout);

}

void HMIDisplay::receiveFromQml(){

    qDebug()<<"test.....";
}
